# 16x16 RPG characters

This asset pack has been downloaded from https://route1rodent.itch.io/16x16-rpg-character-sprite-sheet

Maintained by @route1rodent

itch.io: https://route1rodent.itch.io
Twitter: https://twitter.com/route1rodent
Github: https://github.com/route1rodent